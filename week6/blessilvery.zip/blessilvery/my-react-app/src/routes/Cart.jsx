import React from 'react';

const Cart = () => {
    return <div>장바구니 페이지입니다.</div>;
};

export default Cart;
