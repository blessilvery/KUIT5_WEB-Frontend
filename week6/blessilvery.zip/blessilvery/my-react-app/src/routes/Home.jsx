import React from 'react';
import * as S from './components/shared/Home.styles';
import HomeIndicator from './components/Page_1/HomeIndicator';

const Home = () => {
    return (
        <>
            <S.SectionHeader />
            <S.DeliveryLocationHeader />
            <S.FoodCategory />
            <S.OrderFooter />
            <HomeIndicator />
        </>
    );
};

export default Home;
