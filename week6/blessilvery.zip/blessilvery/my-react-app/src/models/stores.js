
export const foodCategories = [
    { name: "피자1", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자2", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자3", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자4", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자5", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자6", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자7", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자8", image: "/public_assets/pizzaIcon.svg" },
    { name: "피자9", image: "/public_assets/pizzaIcon.svg" },
]

export const storeList = [
    {
        rank: 1,
        name: "샐로리 한남점",
        rating: 4.9,
        reviews: 3919,
        deliveryTime: "15~25분",
        deliveryFee: 2000,
        minOrder: 13000,
        purMethod: "토스결제만 현장결제 안됨"
    },
    {
        rank: 2,
        name: "샐로리 한남점",
        rating: 4.9,
        reviews: 3919,
        deliveryTime: "15~25분",
        deliveryFee: 2000,
        minOrder: 13000,
        purMethod: "토스결제만 현장결제 안됨"
    },
    {
        rank: 3,
        name: "샐로리 한남점",
        rating: 4.9,
        reviews: 3919,
        deliveryTime: "15~25분",
        deliveryFee: 2000,
        minOrder: 13000,
        purMethod: "토스결제만 현장결제 안됨"
    },
    {
        rank: 4,
        name: "샐로리 한남점",
        rating: 4.9,
        reviews: 3919,
        deliveryTime: "15~25분",
        deliveryFee: 2000,
        minOrder: 13000,
        purMethod: "토스결제만 현장결제 안됨"
    },
    {
        rank: 5,
        name: "샐로리 한남점",
        rating: 4.9,
        reviews: 3919,
        deliveryTime: "15~25분",
        deliveryFee: 2000,
        minOrder: 13000,
        purMethod: "토스결제만 현장결제 안됨"
    },
]

export const saladMenu = [
    {
        name: "토마토 샐러드",
        isBest: true,
        price: 7600,
        ingredients: "계란, 옥수수, 양파, 올리브, 베이컨, \n" +
            "시저드레싱"
    },
    {
        name: "토마토 샐러드",
        isBest: false,
        price: 7600,
        ingredients: "계란, 옥수수, 양파, 올리브, 베이컨, \n" +
            "시저드레싱"
    },
    {
        name: "토마토 샐러드",
        isBest: false,
        price: 7600,
        ingredients: "계란, 옥수수, 양파, 올리브, 베이컨, \n" +
            "시저드레싱"
    },
    {
        name: "토마토 샐러드",
        isBest: false,
        price: 7600,
        ingredients: "계란, 옥수수, 양파, 올리브, 베이컨, \n" +
            "시저드레싱"
    },

]