import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Home from './routes/Home';
import Stores from './routes/Stores';
import Cart from './routes/Cart';

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/store', element: <Stores category="샐러드" /> },
  { path: '/cart', element: <Cart /> },
]);

const Main = () => {
  return <RouterProvider router={router} />;
};

export default Main;
