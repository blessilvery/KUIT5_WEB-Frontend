import styled from 'styled-components';
import DeliveryLocationHeaderBase from '../Page_1/DeliveryLocationHeaderBase';
import FoodCategoryBase from '../Page_1/FoodCategory';
import OrderFooterBase from '../Page_1/OrderFooter';
import SectionHeaderBase from '../Page_1/SectionHeader';

export const SectionHeader = styled(SectionHeaderBase)``;
export const DeliveryLocationHeader = styled(DeliveryLocationHeaderBase)``;
export const FoodCategory = styled(FoodCategoryBase)``;
export const OrderFooter = styled(OrderFooterBase)``;
