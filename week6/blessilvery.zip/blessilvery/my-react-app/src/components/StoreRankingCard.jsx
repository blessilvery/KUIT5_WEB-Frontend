const StoreRankingCard = ({store}) =>{
    console.log("123")
    console.log(store.name)
    const { rank, name, rating, reviews, deliveryTime, deliveryFee, minOrder, purMethod } = store;
    return (
        <>
            123
            <div>{name}</div>
            456
        </>
    )
}

export default StoreRankingCard;