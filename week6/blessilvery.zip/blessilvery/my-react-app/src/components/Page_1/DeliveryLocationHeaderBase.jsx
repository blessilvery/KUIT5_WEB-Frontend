import React from 'react';

const DeliveryLocationHeaderBase = () => {
    return (
        <div style={{ padding: '8px 16px', background: '#f5f5f5', fontSize: '14px' }}>
            한남중앙로 40길 (한남 빌리지)(으)로 배달 &gt;
        </div>
    );
};

export default DeliveryLocationHeaderBase;
