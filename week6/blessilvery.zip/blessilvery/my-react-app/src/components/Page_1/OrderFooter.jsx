import React from 'react';

const OrderFooter = () => {
    return (
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 16px', borderTop: '1px solid #eee' }}>
            <div>
                <div style={{ fontSize: '12px', color: '#888' }}>총 주문금액</div>
                <div style={{ fontSize: '16px', fontWeight: 'bold' }}>12,100원</div>
            </div>
            <button style={{ backgroundColor: '#007bff', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '4px' }}>
                주문하기
            </button>
        </div>
    );
};

export default OrderFooter;
