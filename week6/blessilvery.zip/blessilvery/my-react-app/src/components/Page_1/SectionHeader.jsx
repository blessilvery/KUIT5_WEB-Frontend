import React from 'react';

const SectionHeader = () => {
    return (
        <header style={{ padding: '16px', fontWeight: 'bold', fontSize: '18px' }}>
            오늘은 무엇을 먹을까요?
        </header>
    );
};

export default SectionHeader;
