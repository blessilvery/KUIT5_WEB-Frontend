import styled from "styled-components";

export const Greeting =  styled.div`
    display: flex;
    flex-direction: column;
    width: 298px;
    height: 64px;
    margin: 0px 24px 4px;
`